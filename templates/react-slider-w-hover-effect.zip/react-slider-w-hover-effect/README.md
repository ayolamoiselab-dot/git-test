# React Slider w/ Hover Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/hexagoncircle/pen/jgGxKR](https://codepen.io/hexagoncircle/pen/jgGxKR).

A slider/carousel built with React. The x and y coordinates of the current slide are set to CSS variables to create dynamic transition effects on mouseover.

<a href="https://tympanus.net/codrops/2019/08/20/react-slider-with-parallax-hover-effects/" target="_blank">Tutorial available on Codrops</a>