# FAQ

A Pen created on CodePen.io. Original URL: [https://codepen.io/kathykato/pen/MoZJom](https://codepen.io/kathykato/pen/MoZJom).

Minimal FAQ accordion made with vanilla JavaScript.